/******************************************************************************/
/*!
\file   List.cpp
\author Jeong Juyong
\par    e-mail: stack179\@gmail.com
\par    course: CS170
\date   06/03/2013
\brief:
   This is the cpp file contains linked list functions
*/
/******************************************************************************/
 

namespace CS170
{

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
// static members

template <typename T>
int List<T>::Node::s_nodeCount = 0;

/******************************************************************************/
/*!
  \brief
   Return the number of nodes

*/
/******************************************************************************/
template <typename T>
int List<T>::NodeCount(void)
{
  return Node::s_nodeCount;
}

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
// List::Node methods
/******************************************************************************/
/*!

  \brief
    Constructor of node  
    
  \param value
    Value to be data of node
*/
/******************************************************************************/
template <typename T>
List<T>::Node::Node(T value) : data(value)
{
  s_nodeCount++;
}

/******************************************************************************/
/*!

  Destructor of node

*/
/******************************************************************************/
template <typename T>
List<T>::Node::~Node(void)
{
  s_nodeCount--;
}

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
// public methods

/******************************************************************************/
/*!

  Defalut constructor of list

*/
/******************************************************************************/
template <typename T>
List<T>::List(void)
{
  //Set all zero
  m_pHead = 0;
  m_pTail = 0;
  m_size = 0;
}

/******************************************************************************/
/*!

  Destructor of list

*/
/******************************************************************************/
template <typename T>
List<T>::~List(void)
{
  //Make all clear
  Clear();
}

/******************************************************************************/
/*!

  Non-defalut constructor of list
  
  \param list
    This list will be set to input(&list)
*/
/******************************************************************************/
template <typename T>
List<T>::List(const List &list) : m_pHead(0), m_size(0)
{
  //Get right hand side's m_pHead
  Node *rhs_pList = list.m_pHead;

  //Add to end of original list
  while(rhs_pList)
  {
    PushBack(rhs_pList->data);
    rhs_pList = rhs_pList->pNext;
  }

}

/******************************************************************************/
/*!

  Non-defalut constructor of list
  
  \param arrays[]
    This array will be set to input(&list)
    
  \param size
    The size of input array
*/
/******************************************************************************/
template <typename T>
List<T>::List(const T *arrays, int size):
  m_pHead(0), m_size(0)
{
  //Put array members to list
  for(int index = 0 ; (index < size) ;index++)
    PushBack(*(arrays+index));

}

/******************************************************************************/
/*!

  \brief
    Put input value to the front of the list 
  
  \param Value
    This value will be put to front of the list
    
*/
/******************************************************************************/
template <typename T>
void List<T>::PushFront(const T& Value)
{
  //Make new node
  Node *pTemp = MakeNode(Value);

  //Increase the size of the list
  m_size++;
  
  //The case for there's no node
  if(!m_pHead)
    m_pHead = pTemp;

  //Or not, add to front
  else
  {
    pTemp -> pNext = m_pHead;
    m_pHead = pTemp;
  }
}

/******************************************************************************/
/*!

  \brief
    Return the first member of the list 
    
*/
/******************************************************************************/
template <typename T>
T List<T>::Front(void) const
{
    return m_pHead->data;
}

/******************************************************************************/
/*!

  \brief
    Put input value to the end of the list 
  
  \param Value
    This value will be put to end of the list
    
*/
/******************************************************************************/
template <typename T>
void List<T>::PushBack(const T& Value)          
{
  //Get m_pHead
  Node *pList = m_pHead;

  //Increase the size of the list
  m_size++;

  //The case for there's no node
  if(!pList)
  {
    m_pHead = MakeNode(Value);
    m_pTail = m_pHead;
  }

  //The case for put other list to original
  //When cannot know the tail
  else if(pList && !m_pTail)
  {
    //Set the tail
    while(pList->pNext)
      pList = pList->pNext;

    m_pTail = pList;
    m_pTail -> pNext = MakeNode(Value);
    m_pTail = m_pTail ->pNext;
  }

  //The case for put other list to original
  //When we know the tail
  else
  {
    m_pTail -> pNext = MakeNode(Value);
    m_pTail = m_pTail ->pNext;
  }
}

/******************************************************************************/
/*!

  \brief
    Return the size of list
    
*/
/******************************************************************************/
template <typename T>
int List<T>::Size(void) const
{
  return m_size;
}

/******************************************************************************/
/*!

  \brief
    Inform if the list is empty or not
    
*/
/******************************************************************************/
template <typename T>
bool List<T>::IsEmpty(void) const
{
  Node* pList = m_pHead;

  //If there's no m_pHead
  if(!pList)
    return true;

  else
    return false;
}

/******************************************************************************/
/*!

  \brief
    Operator to add two lists
  
  \param list
    This list will be added to end of left list
    
  \return 
    newlist
*/
/******************************************************************************/
template <typename T>
List<T> List<T>::operator+(const List& list) const
{
  List newlist;

  //Use already-made operators
  newlist = (*this);
  newlist += list;

  return newlist;
}

/******************************************************************************/
/*!

  \brief
    Operator to assign one list to other
  
  \param list
    This list will be assigned left list
    
  \return 
    *this 
*/
/******************************************************************************/
template <typename T>
List<T>& List<T>::operator=(const List& list)
{
  Node *rhs_pList = list.m_pHead;

  //Put data of rhs's node to original list
  if(this!=&list)
  {
    while(rhs_pList)
    {
      PushBack(rhs_pList->data);
      rhs_pList = rhs_pList->pNext;
    }
  }

  return *this;
}

/******************************************************************************/
/*!

  \brief
    Operator to add-assign two lists
  
  \param list
    This list will be add-assigned to end of left list
    
  \return
    *this
*/
/******************************************************************************/
template <typename T>
List<T>& List<T>::operator+=(const List& list)
{
  Node* rhs_pList = list.m_pHead;

  //Put data of rhs's node to the end of th original list
  while(rhs_pList)
  {
    PushBack(rhs_pList->data);
    rhs_pList = rhs_pList->pNext; 
  }

  return *this;
}

/******************************************************************************/
/*!

  \brief
    Operator to express array's member as a const
  
  \param index
    This index is the position of specific array's member
    
  \return
    (pList -> data)
*/
/******************************************************************************/
template <typename T>
const T& List<T>::operator[](int index) const
{
  int check = 1;
  Node *pList = m_pHead;
  
  //Check the memver value until check reaches to the "index" 
  while(check <= index)
  {
    pList = pList -> pNext;
    check++;
  }

  return (pList -> data);
}

/******************************************************************************/
/*!

  \brief
    Operator to express array's member as a ono-const
  
  \param index
    This index is the position of specific array's member
    
  \return
    (pList -> data)
*/
/******************************************************************************/
template <typename T>
T& List<T>::operator[](int index)
{
  int check = 1;
  Node *pList = m_pHead;
  
  //Check the memver value until check reaches to the "index" 
  while(check <= index)
  {
    pList = pList -> pNext;
    check++;
  }

  return (pList -> data);
}


/////////////////////////////////////////////////////////////////////////
// Function: List::clear
//  Purpose: Removes all of the nodes in the list.
//   Inputs: None
//  Outputs: None
/////////////////////////////////////////////////////////////////////////
/******************************************************************************/
/*!

  \brief
    Clear all the member of the list
    
*/
/******************************************************************************/
template <typename T>
void List<T>::Clear(void)
{
  while (!IsEmpty())
    PopFront();
}

/******************************************************************************/
/*!

  \brief
    Get rid of the first member of the list
    
*/
/******************************************************************************/
template <typename T>
void List<T>::PopFront(void)            
{
  m_size--;

  //Get m_pHead as pList and store its pNext
  Node* pList = m_pHead;
  Node* nextList= pList->pNext;
    
  //Delete the pList node
  delete pList;
    
  //Set pNext
  m_pHead = nextList;
}

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
// private methods

/////////////////////////////////////////////////////////////////////////
// Function: new_node
//  Purpose: Allocate a node, initialize the data and next pointer
//   Inputs: data - the data to put in the node
//  Outputs: A pointer to the node
/////////////////////////////////////////////////////////////////////////
/******************************************************************************/
/*!

  \brief
    Make a node
    
  \param data
    This data will be put to this node
    
  \return
    node
    
*/
/******************************************************************************/
template <typename T>
typename List<T>::Node *List<T>::MakeNode(const T& data) const
{
  Node *node = new Node(data); // create the node
  node->pNext = 0;              // no next pointer yet
  return node;
}

} // namespace CS170


/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
// non-members

#include <iomanip>

/////////////////////////////////////////////////////////////////////////
// Function: operator<<
//  Purpose: Output the list into an ostream object
//   Inputs:   os - ostream object to output to
//           list - the List to output
//  Outputs: The ostream object that was passed in.
/////////////////////////////////////////////////////////////////////////
/******************************************************************************/
/*!

  \brief
    Print the list
    
  \param os
    List's memebers will be printed by this outstream
    
  \param list
    This list's memebers will be printed
    
*/
/******************************************************************************/
template <typename T>
std::ostream &CS170::operator<<(std::ostream & os, const CS170::List<T> &list)
{
    // Start at the top
  typename CS170::List<T>::Node *pnode = list.m_pHead;

    // Print each item
  while (pnode != 0)
  {
    os << std::setw(4) << pnode->data;
    pnode = pnode->pNext;
  }
  os << std::endl;
  return os;
}



