/******************************************************************************/
/*!
\file   List.h
\author Jeong Juyong
\par    e-mail: stack179\@gmail.com
\par    course: CS170
\date   06/03/2013
\brief:
   This is the h file contains prototypes of functions calcualte Lists
*/
/******************************************************************************/

////////////////////////////////////////////////////////////////////////////////
#ifndef LIST_H
#define LIST_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> /* ostream, endl */

namespace CS170
{
  template <typename T> class List;

  template <typename T>
  std::ostream & operator<<(std::ostream & os, const List<T> &list);

  template <typename T>
  class List ///<! Contains functions and operators for list class
  {
    public:      
      List(void);                     // Default constructor  
      List(const List &list);         // Constructs from an Existing list
      List(const T *array, int size); ///<! Construct a list from a T array  
      ~List(void);                    // Destructor

      void PushFront(const T& Value); // adds the item to the front of the list
      void PushBack(const T& Value);  // adds the item to the end of the list
      void PopFront(void);            // removes the first item in the list
      bool IsEmpty(void) const;       // true if empty, else false
      void Clear(void);               // clears the list
      int  Size(void) const;          // returns the number of items in the list
      T    Front(void) const;         // retrieves the first item in the list
      
      
      List operator+(const List &list) const; // For adding two lists

        
      List& operator=(const List &list);// For assigning one list to another
      List& operator+=(const List &list);// For adding to a list "in place" 
      
      // Overloaded subscript operators
      const T& operator[](int index) const;
      T&       operator[](int index);

        
     friend std::ostream & operator<< <T> 
     (std::ostream & os, const List<T> &list);///<! Outstream operator
     
       // Returns the number of Nodes that have been created
     static int NodeCount(void);

    private:
        // Used to build the linked list
      struct Node  ///<! Node structor
      {
        Node(T value);  ///<! non-default constructor
        ~Node(void);    ///<! destructor
        Node *pNext;    ///<! pointer to the next Node
        T data;         ///<! the actual data in the node
        
        static int s_nodeCount; ///<! number of Nodes created
      }; 

      Node* m_pHead;  ///<! pointer to the head of the list
      Node* m_pTail;  ///<! pointer to the last node
      int   m_size;   ///<! number of items on the list
      
      Node* MakeNode(const T& data) const;  ///<! make a node including data

  };

} // namespace CS170

#include "List.cpp"

#endif
////////////////////////////////////////////////////////////////////////////////

