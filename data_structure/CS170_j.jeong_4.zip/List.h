/******************************************************************************/
/*!
\file   List.h
\author Jeong Juyong
\par    e-mail: stack179\@gmail.com
\par    course: CS170
\date   05/15/2013
\brief:
   This is the h file contains prototypes of functions calcualte Lists
*/
/******************************************************************************/

#ifndef LIST_H
#define LIST_H
#include <iostream> // ostream

//! The namespace for the CS170 class
namespace CS170
{
  class List  ///<! Contains functions and operators for list class
  {
    public:
        List(void);
        List(const List& list);
        List(const int array[], int size);
        ~List(void);

        // Six methods:
        void PushFront(int input);  
        void PushBack(int input);  
        int PopFront(void);         
        int size(void) const;       
        bool IsEmpty(void) const;   
        void Clear(void);           

        List& operator=(const List& rhs);        
        List& operator+=(const List& rhs);       
        List operator+(const List& rhs);         
        const int& operator[](int index) const; 
        int& operator[](int index);              

        // Output operator for printing lists (<<)
      friend std::ostream & operator<<(std::ostream & os, const List& list);

        // Returns the number of Lists that have been created
      static int ObjectCount(void);

    private:
        // used to build a linked list of integers
      struct Node ///<! Contaions the elements of node
      {
        Node *pNext;  ///<! pointer to the next Node
        int   data;   ///<! the actual data in the node
      };

      Node* m_pHead;  ///<! pointer to the head of the list
      Node* m_pTail;  ///<! pointer to the last node
      int   m_size;   ///<! number of items on the list

      static int s_m_ObjectCount;     ///<! number of Lists created
      Node* MakeNode(int data) const; // allocate node, initialize data/next
  };

} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
