/******************************************************************************/
/*!
\file   List.cpp
\author Jeong Juyong
\par    e-mail: stack179\@gmail.com
\par    course: CS170
\date   05/15/2013
\brief:
   This is the cpp file contains functions calcualte Lists
*/
/******************************************************************************/

#include "List.h"  // List class
#include <iomanip> // setw

namespace CS170
{
//Set satatic value here 
int List::s_m_ObjectCount = 0;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// public methods in this order: 
// Constructors (default, copy, non-defaults), destructor, operators, others

/******************************************************************************/
/*!

Default constructor for List class

*/
/******************************************************************************/
List::List(void)
{
  //Swt all zero
  m_pHead = 0;
  m_pTail = 0;
  m_size = 0;
  s_m_ObjectCount++;
}

/******************************************************************************/
/*!

Non-default constructor for List class

  \param rhs
    Will be copied to original list

*/
/******************************************************************************/
List::List(const List& rhs):
  m_pHead(0), m_size(0)
{
  //Get right hand side's m_pHead
  Node *rhs_pList = rhs.m_pHead;

  //Add to end of original list
  while(rhs_pList)
  {
    PushBack(rhs_pList->data);
    rhs_pList = rhs_pList->pNext;
  }
  
  //Increase count of the number of creating list
  s_m_ObjectCount++;
}

/******************************************************************************/
/*!

Non-default constructor for List class using array
  \param arrays[]
    Will be put to the original list
  
  \param size
    Wiil be criteria of checking array
*/
/******************************************************************************/
List::List(const int arrays[], int size):
  m_pHead(0), m_size(0)
{
  for(int index = 0 ; (index < size) ;index++)
    PushBack(*(arrays+index));

  //Increase count of the number of creating list
  s_m_ObjectCount++;
}

/******************************************************************************/
/*!

Non-default constructor for List class using array

*/
/******************************************************************************/
List::~List(void)
{
  //Make all clear
  Clear();
}

/******************************************************************************/
/*!

Put value into the front of the list

  \param input
   The value that will be put to front of the list

*/
/******************************************************************************/
void List::PushFront(int input)
{
  //Make new node
  Node *pTemp = MakeNode(input);

  //Increase the size of the list
  m_size++;
  
  //The case for there's no node
  if(!m_pHead)
    m_pHead = pTemp;

  //Or not, add to front
  else
  {
    pTemp -> pNext = m_pHead;
    m_pHead = pTemp;
  }
}

/******************************************************************************/
/*!

Put value into the end of the list

  \param input
   The value that will be put to end of the list

*/
/******************************************************************************/
void List::PushBack(int input)          
{
  //
  Node *pList = m_pHead;

  //Increase the size of the list
  m_size++;

  //The case for there's no node
  if(!pList)
  {
    m_pHead = MakeNode(input);
    m_pTail = m_pHead;
  }

  //The case for put other list to original
  //When cannot know the tail
  else if(pList && !m_pTail)
  {
    //Set the tail
    while(pList->pNext)
      pList = pList->pNext;

    m_pTail = pList;
    m_pTail -> pNext = MakeNode(input);
    m_pTail = m_pTail ->pNext;
  }

  //The case for put other list to original
  //When we know the tail
  else
  {
    m_pTail -> pNext = MakeNode(input);
    m_pTail = m_pTail ->pNext;
  }
}

/******************************************************************************/
/*!

  Return the private m_size 

  \return 
    m_size
*/
/******************************************************************************/
int List::size(void) const
{
  return m_size;
}

/******************************************************************************/
/*!

Delete the front node of the list

  \return 
    -1 or tempItem

*/
/******************************************************************************/
int List::PopFront(void)            
{
  //Store the next address
  int tempItem = m_pHead->data;
  m_size--;

  //Case for there's no m_pHead
  if(!m_pHead)
      return -1;

  //If m_pHead exists
  else
  {
    //Get m_pHead as pList and store its pNext
    Node* pList = m_pHead;
    Node* nextList= pList->pNext;
    
    //Delete the pList node
    delete pList;
    
    //Set pNext
    m_pHead = nextList;

    return tempItem;
  }
}

/******************************************************************************/
/*!

Inform that list is empty or not

  \return 
    true or false

*/
/******************************************************************************/
bool List::IsEmpty(void) const
{
  Node* pList = m_pHead;

  //If there's no m_pHead
  if(!pList)
    return true;

  else
    return false;
}

/******************************************************************************/
/*!

All clear the nodes from the list

*/
/******************************************************************************/
void List::Clear(void)              
{
  Node* pList = m_pHead;

  //Delete the all of the nodes in the list
  //using popfront function
  while(pList)
  {
    Node* moveList= pList->pNext;
    PopFront();
    pList = moveList;
  }
}

/******************************************************************************/
/*!

  Operator for assignment of lists 

  \param rhs
    The list will be assigned to the left-hand side list
    
  \return *this
*/
/******************************************************************************/
List& List::operator=(const List& rhs)
{
  Node *rhs_pList = rhs.m_pHead;

  //Put data of rhs's node to original list
  while(rhs_pList)
  {
    PushBack(rhs_pList->data);
    rhs_pList = rhs_pList->pNext;
  }

  return *this;
}

/******************************************************************************/
/*!

  Operator for adding of lists 

  \param rhs
    The list will be add-assigned to the left-hand side list
    
  \return *this
*/
/******************************************************************************/
List& List::operator+=(const List& rhs)
{
  Node* rhs_pList = rhs.m_pHead;

  //Put data of rhs's node to the end of th original list
  while(rhs_pList)
  {
    PushBack(rhs_pList->data);
    rhs_pList = rhs_pList->pNext; 
  }

  return *this;
  
}

/******************************************************************************/
/*!

  Operator for adding of lists 

  \param rhs
    The list will be added to the left-hand side list
    
  \return newlist
*/
/******************************************************************************/
List List::operator+(const List& rhs)
{
  List newlist;

  //Use already-made operators
  newlist = (*this);
  newlist += rhs;

  return newlist;
}

/******************************************************************************/
/*!

  Operator for array of lists for const

  \param index
    Will return "index"th array member  
    
  \return (pList -> data)
*/
/******************************************************************************/
const int& List::operator[](int index) const
{
  int check = 1;
  Node *pList = m_pHead;
  
  //Check the memver value until check reaches to the "index" 
  while(check <= index)
  {
    pList = pList -> pNext;
    check++;
  }

  return (pList -> data);
}
 
/******************************************************************************/
/*!

  Operator for array of lists for non-const

  \param index
    Will return "index"th array member  
    
  \return (pList -> data)
*/
/******************************************************************************/
int& List::operator[](int index)
{
  int check = 1;
  Node *pList = m_pHead;
  
  //Check the memver value until check reaches to the "index" 
  while(check <= index)
  {
    pList = pList -> pNext;
    check++;
  }

  return (pList -> data);
}

/******************************************************************************/
/*!

  Return private value, s_m_ObjectCount
  
    \return 
      s_m_ObjectCount
*/
/******************************************************************************/
int List::ObjectCount(void)
{
  return s_m_ObjectCount;
}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// private methods

/******************************************************************************/
/*!

  Make node for the list class

  \param data
    Will be put the "data" part of the node 
    
  \return newNode
*/
/******************************************************************************/
List::Node* List::MakeNode(int data) const
{
  //Allocate new node and set its data and pNext
  Node* newNode = new Node;
  newNode -> data = data; 
  newNode -> pNext = 0;

  return newNode;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// non-member methods

/******************************************************************************/
/*!

  Make node for the list class

  \param os
    out stream that will take result of the function
  
  \param list
    Will be printed by os
    
  \return os
*/
/******************************************************************************/
std::ostream& operator<<(std::ostream& os, const List& list)
{
    // Start at the first node
  List::Node *pNode = list.m_pHead;
    // Until we reach the end of the list
  while (pNode != 0)
  {
    os << std::setw(4) << pNode->data; // print the data in this node
    pNode = pNode->pNext;               // move to the next node
  }
  os << std::endl; // extra newline for readability
  return os;
}

} //namespace CS170
