/*****************************************************************************/
/*!
\file   OAHashTable.h
\author Minsu Kang
\par    email: minsu9486\@gmail.com
\par    CS280
\par    Assignment #5
\date   2015/06/08
\brief

This file contains the interfaces for every needed for the OAHashTable.

*/
/*****************************************************************************/

//---------------------------------------------------------------------------
#ifndef OAHASHTABLE_H
#define OAHASHTABLE_H
//---------------------------------------------------------------------------

#ifdef _MSC_VER
// Suppress warning: C++ Exception Specification ignored
#pragma warning(disable: 4290 ) 
#endif

#include <string>
#include "Support.h"

// client-provided hash function: takes a key and table size,
//! returns an index in the table.
typedef unsigned (*HASHFUNC)(const char *, unsigned);

//! Max length of our "string" keys
#define MAX_KEYLEN 10

//! OAHashTableException Class
class OAHashTableException
{
  private:  
    int error_code_;      //!< The description to send
    std::string message_; //!< The exception code

  public:
/*****************************************************************************/
/*!

\brief
Constructor for the OAHashTableException class.

\param ErrCode
The exception code

\param Message
The description to send

\return
None.

*/
/*****************************************************************************/
    OAHashTableException(int ErrCode, const std::string& Message) :
        error_code_(ErrCode), message_(Message) {};

/*****************************************************************************/
/*!

\brief
Destructor for the OAHashTableException class.

\return
None

*/
/*****************************************************************************/
    virtual ~OAHashTableException() {
    }

/*****************************************************************************/
/*!

\brief
it returns the error code

\return
The exception code

*/
/*****************************************************************************/
    virtual int code(void) const { 
      return error_code_; 
    }

/*****************************************************************************/
/*!

\brief
it returns the string of description

\return
The string of description

*/
/*****************************************************************************/
    virtual const char *what(void) const {
      return message_.c_str();
    }

    //! Exception Cases
    enum OAHASHTABLE_EXCEPTION {E_ITEM_NOT_FOUND, E_DUPLICATE, E_NO_MEMORY};
};

//! Deletion Policy
enum OAHTDeletionPolicy {MARK, PACK};

//! OAHashTable statistical info
struct OAHTStats
{
/*****************************************************************************/
/*!

\brief
Default Constructor for the OAHTStats struct.

\return
None.

*/
/*****************************************************************************/
  OAHTStats(void) : Count_(0), TableSize_(0), Probes_(0), Expansions_(0),
                    PrimaryHashFunc_(0), SecondaryHashFunc_(0) {};
  unsigned Count_;             //!< Number of elements in the table
  unsigned TableSize_;         //!< Size of the table (total slots)
  unsigned Probes_;            //!< Number of probes performed
  unsigned Expansions_;        //!< Number of times the table grew
  HASHFUNC PrimaryHashFunc_;   //!< Pointer to primary hash function
  HASHFUNC SecondaryHashFunc_; //!< Pointer to secondary hash function
};

//! OAHashTable Class
template <typename T>
class OAHashTable
{
  public:

    typedef void (*FREEPROC)(T); //!< client-provided free proc

    //! Configuration values for the table
    struct OAHTConfig
    {
/*****************************************************************************/
/*!

\brief
Non-Default Constructor for the OAHTConfig struct.

\param InitialTableSize
Size of the table (total slots)

\param PrimaryHashFunc
Pointer to primary hash function

\param SecondaryHashFunc
Pointer to secondary hash function

\param MaxLoadFactor
The max load rate

\param GrowthFactor
The grow rate

\param Policy
The deleting policy

\param FreeProc
Free Process

\return
None.

*/
/*****************************************************************************/
      OAHTConfig(unsigned InitialTableSize, 
                 HASHFUNC PrimaryHashFunc, 
                 HASHFUNC SecondaryHashFunc = 0,
                 double MaxLoadFactor = 0.5,
                 double GrowthFactor = 2.0, 
                 OAHTDeletionPolicy Policy = PACK,
                 FREEPROC FreeProc = 0) :

        InitialTableSize_(InitialTableSize), PrimaryHashFunc_(PrimaryHashFunc),
        SecondaryHashFunc_(SecondaryHashFunc), MaxLoadFactor_(MaxLoadFactor), 
        GrowthFactor_(GrowthFactor), DeletionPolicy_(Policy),
        FreeProc_(FreeProc) {}

      unsigned InitialTableSize_;  //!< Size of the table (total slots)
      HASHFUNC PrimaryHashFunc_;   //!< Pointer to primary hash function
      HASHFUNC SecondaryHashFunc_; //!< Pointer to secondary hash function
      double MaxLoadFactor_;       //!< The max load rate
      double GrowthFactor_;        //!< The grow rate
      OAHTDeletionPolicy DeletionPolicy_; //!< The deleting policy
      FREEPROC FreeProc_;          //!< Free Process
    };
      
    //! Slots that will hold the key/data pairs
    struct OAHTSlot
    {
      char Key[MAX_KEYLEN]; //!< Key is a string
      T Data;               //!< Client data is external
      //! Slot States
      enum OAHTSlot_State {OCCUPIED, UNOCCUPIED, DELETED};
      OAHTSlot_State State; //!< Current State
      int reserved;         //!< Origin Hash Value
    };

    OAHashTable(const OAHTConfig& Config);
    ~OAHashTable();

      // Insert a key/data pair into table. Throws an exception if the
      // insertion is unsuccessful.
    void insert(const char *Key, const T& Data) throw(OAHashTableException);

      // Delete an item by key. Throws an exception if the key doesn't exist.
      // Compacts the table by moving key/data pairs, if necessary
    void remove(const char *Key) throw(OAHashTableException);

      // Find and return data by key (throws exception if not found)
    const T& find(const char *Key) const throw(OAHashTableException);

      // Removes all items from the table (Doesn't deallocate table)
    void clear(void);

      // Allow the client to peer into the data
    OAHTStats GetStats(void) const;
    const OAHTSlot* GetTable(void) const;

  private:
      // Initialize the table after an allocation
    void InitTable(void);

      // Expands the table when the load factor reaches a certain point
      // (greater than MaxLoadFactor) Grows the table by GrowthFactor,
      // making sure the new size is prime by calling GetClosestPrime
    void GrowTable(void) throw(OAHashTableException);

      // Workhorse method to locate an item (if it exists)
      // Returns the index of the item in the table
      // Sets Slot to point to the slot in the table where it belongs 
      // Returns -1 if it's not in the table
    int IndexOf(const char *Key, OAHTSlot* &Slot) const;
    
    // Other private fields and methods...
    OAHTSlot* m_Table; //!< Slots

    OAHTStats* m_Stats;     //!< The class's stats
    double m_MaxLoadFactor; //!< The max load
    double m_GrowthFactor;  //!< The grow rate
    OAHTDeletionPolicy m_DeletingPolicy; //!< The deleting policy
    FREEPROC m_FreeProc;                 //!< Free Process

    void MarkRemove(const char *Key) throw(OAHashTableException);
    void PackRemove(const char *Key) throw(OAHashTableException);
};

#include "OAHashTable.cpp"

#endif
