/*****************************************************************************/
/*!
\file   OAHashTable.cpp
\author Minsu Kang
\par    email: minsu9486\@gmail.com
\par    CS280
\par    Assignment #5
\date   2015/06/08
\brief

This class contains the implementation for the OAHashTable class.

*/
/*****************************************************************************/

#include <cmath> // For cill

/*****************************************************************************/
/*!

\brief
Constructor for the OAHashTable class.

\param Config
The configuration of the hash table

\return
None.

*/
/*****************************************************************************/
template <typename T>
OAHashTable<T>::OAHashTable(const OAHTConfig& Config)
{
    // Allocate the stats' pointer
    m_Stats = new OAHTStats;

    // Init for others
    m_MaxLoadFactor  = Config.MaxLoadFactor_;
    m_GrowthFactor   = Config.GrowthFactor_;
    m_DeletingPolicy = Config.DeletionPolicy_;
    m_FreeProc       = Config.FreeProc_;

    // Init for stats
    m_Stats->TableSize_ = Config.InitialTableSize_;
    m_Stats->PrimaryHashFunc_ = Config.PrimaryHashFunc_;
    m_Stats->SecondaryHashFunc_ = Config.SecondaryHashFunc_;

    // Init the table
    m_Table = new OAHTSlot[m_Stats->TableSize_];
    InitTable();
}

/*****************************************************************************/
/*!

\brief
Destructor for the OAHashTable class.

\return
None.

*/
/*****************************************************************************/
template <typename T>
OAHashTable<T>::~OAHashTable()
{
    clear();        // Deallocate the table

    delete m_Stats; // Deallocate the stats
    delete[] m_Table;
}

/*****************************************************************************/
/*!

\brief
Insert the key and data to the table

\param Key
The given key

\param Data
The given data

\return
None.

*/
/*****************************************************************************/
template <typename T>
void OAHashTable<T>::insert(const char *Key, const T& Data)
                                                    throw(OAHashTableException)
{
    // Calculate the load factor
    const double loadFactor = ((double)m_Stats->Count_ + 1)
                              / (double)m_Stats->TableSize_;

    // Determine whether grow or not
    if (loadFactor > m_MaxLoadFactor)
        GrowTable();

    // The original hash value
    const unsigned hashValue
        = m_Stats->PrimaryHashFunc_(Key, m_Stats->TableSize_);

    // assume linear probing
    unsigned stride = 1;
    // If we are doing double hashing, get the stride/increment
    if (m_Stats->SecondaryHashFunc_)
        stride = m_Stats->SecondaryHashFunc_(Key, m_Stats->TableSize_ - 1) + 1;

    // Loop if collision is occured
    for (unsigned i = 0; i < m_Stats->TableSize_; ++i, ++(m_Stats->Probes_))
    {
        // Changed hashvalue
        const unsigned fixedValue
            = (hashValue + (i * stride)) % m_Stats->TableSize_;
        const bool duplicated = !std::strcmp((m_Table + fixedValue)->Key, Key);

        if (duplicated)
            throw OAHashTableException(OAHashTableException::E_DUPLICATE,
                                       "insert : E_DUPLICATE");

        // Ignore the occupied slot
        if ((m_Table + fixedValue)->State != OAHTSlot::OCCUPIED)
        {
            ++(m_Stats->Probes_);

            // Copy the string with storing the others
            std::strcpy((m_Table + fixedValue)->Key, Key);
            (m_Table + fixedValue)->Data = Data;
            (m_Table + fixedValue)->State = OAHTSlot::OCCUPIED;
            (m_Table + fixedValue)->reserved = hashValue;

            ++(m_Stats->Count_);

            return; // Done
        }
    }
     
    // No memory
    throw OAHashTableException(OAHashTableException::E_NO_MEMORY,
                               "insert : E_NO_MEMORY");
}

/*****************************************************************************/
/*!

\brief
Remove the key and data from the table

\param Key
The given key

\return
None.

*/
/*****************************************************************************/
template <typename T>
void OAHashTable<T>::remove(const char *Key) throw(OAHashTableException)
{
    // Mark or Pack
    if (m_DeletingPolicy == MARK)
        MarkRemove(Key);
    else
        PackRemove(Key);
}

/*****************************************************************************/
/*!

\brief
Find the key from the table, then return the data

\param Key
The given key

\return
0~ = The found data
-1 = NOT_FOUND

*/
/*****************************************************************************/
template <typename T>
const T& OAHashTable<T>::find(const char *Key) const
                                                    throw(OAHashTableException)
{
    // A empty slot
    OAHTSlot* targetSlot;

    // Find the index
    if (IndexOf(Key, targetSlot) == -1)
        throw OAHashTableException(OAHashTableException::E_ITEM_NOT_FOUND,
                                   "Item not found in table.");
    else
        return targetSlot->Data;
}

/*****************************************************************************/
/*!

\brief
Clear all slots

\return
None

*/
/*****************************************************************************/
template <typename T>
void OAHashTable<T>::clear(void)
{
    for (unsigned i = 0; i < m_Stats->TableSize_; ++i)
    {
        // Make to a unoccupied slot
        if (m_Table[i].State != OAHTSlot::UNOCCUPIED)
        {
            std::strcpy(m_Table[i].Key, "");
            if (m_FreeProc != NULL)
                m_FreeProc(m_Table[i].Data);
            m_Table[i].Data = NULL;
            m_Table[i].State = OAHTSlot::UNOCCUPIED;
        }
    }

    // Now, all slots are empty
    m_Stats->Count_ = 0;
}

/*****************************************************************************/
/*!

\brief
Return the current stats

\return
The current stats

*/
/*****************************************************************************/
template <typename T>
OAHTStats OAHashTable<T>::GetStats(void) const
{
    return *m_Stats;
}

/*****************************************************************************/
/*!

\brief
Return the table

\return
The table

*/
/*****************************************************************************/
template <typename T>
const typename OAHashTable<T>::OAHTSlot* OAHashTable<T>::GetTable(void) const
{
    return m_Table;
}

/*****************************************************************************/
/* Private Functions *********************************************************/

/*****************************************************************************/
/*!

\brief
Initialize all table's state

\return
None

*/
/*****************************************************************************/
template <typename T>
void OAHashTable<T>::InitTable(void)
{
    for (unsigned i = 0; i < m_Stats->TableSize_; ++i)
        (m_Table + i)->State = OAHTSlot::UNOCCUPIED;
}

/*****************************************************************************/
/*!

\brief
Expend the memory, then copy

\return
None

*/
/*****************************************************************************/
template <typename T>
void OAHashTable<T>::GrowTable(void) throw(OAHashTableException)
{
    // Calculate the New Size
    double factor = std::ceil(m_Stats->TableSize_ * m_GrowthFactor);
    unsigned new_size = GetClosestPrime(static_cast<unsigned>(factor));

    // Old HashTable with re-init
    OAHTSlot* oldTable = m_Table;
    unsigned oldSize   = m_Stats->TableSize_;

    // New HashTable with re-init
    m_Table             = new OAHTSlot[new_size];
    m_Stats->Count_     = 0;
    m_Stats->TableSize_ = new_size;
    InitTable();

    // Re-Insert
    for (unsigned i = 0; i < oldSize; ++i)
    {
        if ((oldTable + i)->State == OAHTSlot::OCCUPIED)
            insert((oldTable + i)->Key, (oldTable + i)->Data);
    }

    delete[] oldTable;

    ++(m_Stats->Expansions_);
}

/*****************************************************************************/
/*!

\brief
Find the index and the slot

\param Key
The given key

\param Slot
The given empty slot

\return
The foun index

*/
/*****************************************************************************/
template <typename T>
int OAHashTable<T>::IndexOf(const char *Key, OAHTSlot* &Slot) const
{
    // The original hash value
    const unsigned hashValue
        = m_Stats->PrimaryHashFunc_(Key, m_Stats->TableSize_);

    // assume linear probing
    unsigned stride = 1;
    // If we are doing double hashing, get the stride/increment
    if (m_Stats->SecondaryHashFunc_)
        stride = m_Stats->SecondaryHashFunc_(Key, m_Stats->TableSize_ - 1) + 1;

    // Loop as much as the size
    for (unsigned i = 0; i < m_Stats->TableSize_; ++i, ++(m_Stats->Probes_))
    {
        // Changed hashvalue
        const unsigned fixedValue
            = (hashValue + (i * stride)) % m_Stats->TableSize_;

        // Ignore the occupied slot
        if ((m_Table + fixedValue)->State == OAHTSlot::OCCUPIED)
        {
            // Compare the two strings
            if (!std::strcmp((m_Table + fixedValue)->Key, Key))
            {
                // Fill the slot
                Slot = (m_Table + fixedValue);
                ++(m_Stats->Probes_);

                return fixedValue; // The index
            }
        }
        // Returns -1 if it's not in the table
        else if ((m_Table + fixedValue)->State == OAHTSlot::UNOCCUPIED)
        {
            ++(m_Stats->Probes_);

            return -1;
        }
    }

    // Returns -1 if it's not in the table
    return -1;
}

/*****************************************************************************/
/*!

\brief
Remove a slot by MARK method

\param Key
The given key

\return
None

*/
/*****************************************************************************/
template <typename T>
void OAHashTable<T>::MarkRemove(const char *Key) throw(OAHashTableException)
{
    // A empty slot
    OAHTSlot* targetSlot;

    // Find the index
    int index = IndexOf(Key, targetSlot);

    if (index == -1)
        throw OAHashTableException(OAHashTableException::E_ITEM_NOT_FOUND,
        "Key not in table.");

    // Make empty the target slot
    std::strcpy(m_Table[index].Key, "");
    if (m_FreeProc != NULL)
        m_FreeProc(m_Table[index].Data);
    m_Table[index].Data = NULL;
    m_Table[index].State = OAHTSlot::DELETED;
    --m_Stats->Count_;
}

/*****************************************************************************/
/*!

\brief
Remove a slot by PACK method

\param Key
The given key

\return
None

*/
/*****************************************************************************/
template <typename T>
void OAHashTable<T>::PackRemove(const char *Key) throw(OAHashTableException)
{
    // A empty slot
    OAHTSlot* targetSlot;

    // Find the index
    int index = IndexOf(Key, targetSlot);
    const int endIndex = index;

    if (index == -1)
        throw OAHashTableException(OAHashTableException::E_ITEM_NOT_FOUND,
                                   "Key not in table.");

    // Make empty the target slot
    std::strcpy(m_Table[index].Key, "");
    if (m_FreeProc != NULL)
        m_FreeProc(m_Table[index].Data);
    m_Table[index].Data = NULL;
    m_Table[index].State = OAHTSlot::UNOCCUPIED;
    --m_Stats->Count_;

    // Loop until empty slot & the max size
    while (m_Table[++index %= m_Stats->TableSize_].State
                                                        != OAHTSlot::UNOCCUPIED
           && index != endIndex)
    {
        // Ignore the slot that deploied on exacted position
        if (m_Table[index].reserved != index)
        {
            char pKey[MAX_KEYLEN];
            std::strcpy(pKey, m_Table[index].Key);
            T data  = m_Table[index].Data;

            // Make empty the tracking slot
            std::strcpy(m_Table[index].Key, "");
            if (m_FreeProc != NULL)
                m_FreeProc(m_Table[index].Data);
            m_Table[index].Data = NULL;
            m_Table[index].State = OAHTSlot::UNOCCUPIED;
            --m_Stats->Count_;

            // Insert to the previous slot
            insert(pKey, data);
        }
        else
            ++m_Stats->Probes_;
    }
}